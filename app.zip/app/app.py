import argparse
import sys

from openfhe import *

class CKKSParser:
    def __init__(self):
        self.context = CryptoContext()
        self.public_key = None
        self.input = None


    def load(self, args):
        self.init_context(args.cc)
        self.init_public_key(args.key_pub)
        self.init_eval_mult_key(args.key_mult)
        self.init_rotation_key(args.key_rot)
        self.init_ciphertext(args.sample)


    def init_context(self, context_path):
        self.context, ok = DeserializeCryptoContext(context_path, BINARY)
        if not ok:
            raise Exception('load crypto context')


    def init_public_key(self, public_key_path):
        self.public_key, ok = DeserializePublicKey(public_key_path, BINARY)
        if not ok:
            raise Exception('load public key')


    def init_eval_mult_key(self, eval_key_path):
        if not self.context.DeserializeEvalMultKey(eval_key_path, BINARY):
            raise Exception('load mult key')


    def init_rotation_key(self, rotation_key_path):
        if not self.context.DeserializeEvalAutomorphismKey(rotation_key_path, BINARY):
            raise Exception('load rotation key')
        

    def init_ciphertext(self, ciphertext_path):
        self.input, ok = DeserializeCiphertext(ciphertext_path, BINARY)
        if not ok:
            raise Exception('load ciphertext')
 
def solve(inp, cc, pub_key):
    # put your solution here
    coefs = [9.999962350661752e-01,
    9.961808864042003e-01,
    4.892419015184620e-01,
    1.544794597916289e-01,
    3.402645877200605e-02,
    5.308589368342047e-03,
    5.741881580105659e-04,
    4.0776892561084950e-05,
    1.7022006971438345e-06,
	3.1527829096200395e-08
    ]
    
    x = inp
    
    x2 = cc.EvalMult(x, coefs[2]);
    x3 = cc.EvalMult(x, coefs[3]);
    x4 = cc.EvalMult(x, coefs[4]);
    x5 = cc.EvalMult(x, coefs[5]);
    x6 = cc.EvalMult(x, coefs[6]);
    x7 = cc.EvalMult(x, coefs[7]);
    x8 = cc.EvalMult(x, coefs[8]);
    x9 = cc.EvalMult(x, coefs[9]);

    x2 = cc.EvalMult(x2, x);
    x3 = cc.EvalMult(x3, x);
    x4 = cc.EvalMult(x4, x);
    x5 = cc.EvalMult(x5, x);
    x6 = cc.EvalMult(x6, x);
    x7 = cc.EvalMult(x7, x);
    x8 = cc.EvalMult(x8, x);
    x9 = cc.EvalMult(x9, x);
    
    res = cc.EvalMult(x, coefs[1]);
    res = cc.EvalAdd(res, coefs[0]);
    res = cc.EvalAdd(res, x2);
    res = cc.EvalAdd(res, x3);
    res = cc.EvalAdd(res, x4);
    res = cc.EvalAdd(res, x5);
    res = cc.EvalAdd(res, x6);
    res = cc.EvalAdd(res, x7);
    res = cc.EvalAdd(res, x8);
    res = cc.EvalAdd(res, x9);
    
    num = res

    for i in range(12):
        r = 1 << i
        temp = cc.EvalRotate(res, r)
        res = cc.EvalAdd(res, temp)
    
    res = cc.EvalMult(res, 1./10000)
    den = cc.EvalDivide(res, a=10000, b=20000, degree=7)
    den = cc.EvalMult(den, 1./10000)
    return cc.EvalMult(num, den)


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('--key_pub')
        parser.add_argument('--key_mult')
        parser.add_argument('--key_rot')
        parser.add_argument('--cc')
        parser.add_argument('--sample')
        parser.add_argument('--output')
        args = parser.parse_args()

        a = CKKSParser()
        a.load(args)
        
        a.context.Enable(PKESchemeFeature.PKE)
        a.context.Enable(PKESchemeFeature.KEYSWITCH)
        a.context.Enable(PKESchemeFeature.LEVELEDSHE)
        a.context.Enable(PKESchemeFeature.ADVANCEDSHE)

        answer = solve(a.input, a.context, a.public_key)

        if not SerializeToFile(args.output, answer, BINARY):
            raise Exception('output serialization failed')

    except Exception as err:
        print(f'execution error: {err}')
        sys.exit(1)
