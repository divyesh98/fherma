import argparse
import sys
from openfhe import *
import numpy as np
import time

class CKKSParser:
    def __init__(self):
        self.context = CryptoContext()
        self.public_key = None
        self.input = None

    def load(self, args):
        self.init_context(args.cc)
        self.init_public_key(args.key_public)
        self.init_eval_mult_key(args.key_mult)
        self.init_rotation_key(args.key_rot)
        self.init_ciphertext(args.sample)

    def init_context(self, context_path):
        self.context, ok = DeserializeCryptoContext(context_path, BINARY)
        if not ok:
            raise Exception('load crypto context')

    def init_public_key(self, public_key_path):
        self.public_key, ok = DeserializePublicKey(public_key_path, BINARY)
        if not ok:
            raise Exception('load public key')

    def init_eval_mult_key(self, eval_key_path):
        if not self.context.DeserializeEvalMultKey(eval_key_path, BINARY):
            raise Exception('load mult key')

    def init_rotation_key(self, rotation_key_path):
        if not self.context.DeserializeEvalAutomorphismKey(rotation_key_path, BINARY):
            raise Exception('load rotation key')
        
    def init_ciphertext(self, ciphertext_path):
        self.input, ok = DeserializeCiphertext(ciphertext_path, BINARY)
        if not ok:
            raise Exception('load ciphertext')


def _make_const_like(cc, ref_ct, c):
    z = cc.EvalMultByConstant(ref_ct, 0.0)
    return cc.EvalAddConstant(z, float(c))


def exp50_from_exp10(cc, e10):
    e2 = cc.EvalMult(e10, e10)
    e4 = cc.EvalMult(e2, e2)
    e5 = cc.EvalMult(e4, e10)
    return e5


def _all_sum_slots(cc, ct, n_slots):
    s = ct
    step = 1
    while step < n_slots:
        s = cc.EvalAdd(s, cc.EvalRotate(s, step))
        step <<= 1
    return s
    
def _reciprocal_newton(cc, s_ct, n_slots, iters=3):
    y = _make_const_like(cc, s_ct, 1.0 / float(n_slots))
    two = _make_const_like(cc, s_ct, 2.0)
    for _ in range(iters):
        sy  = cc.EvalMult(s_ct, y)     # s * y
        u   = cc.EvalSub(two, sy)      # 2 - s*y
        y   = cc.EvalMult(y, u)        # y * (2 - s*y)
    return y

def solve(x, cc, pub_key):
    z = cc.EvalSub(x, 20)
    t = cc.EvalMult(z, 1./50)

    coefs = [9.999508010664620583e-01,
            9.993196763770203717e+00,
            4.976597575969380216e+01,
            1.631479585009651316e+02,
            3.877304047051997600e+02,
            6.868059310109998705e+02,
            8.974147541861727859e+02,
            8.342804183715653608e+02,
            5.179747703315474610e+02,
            1.912757983992460709e+02,
            3.161752487884736951e+01]

    e10 = cc.EvalPoly(t, coefs)
    e50 = exp50_from_exp10(cc, e10)

    s = _all_sum_slots(cc, e50, n_slot
    inv_s = _reciprocal_newton(cc, s, n_slots, iters=3)

    softmax_ct = cc.EvalMult(e50, inv_s)
    return softmax_ct


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('--key_public')
        parser.add_argument('--key_mult')
        parser.add_argument('--key_rot')
        parser.add_argument('--cc')
        parser.add_argument('--sample')
        parser.add_argument('--output')
        args = parser.parse_args()

        a = CKKSParser()
        a.load(args)
        
        a.context.Enable(PKESchemeFeature.PKE)
        a.context.Enable(PKESchemeFeature.KEYSWITCH)
        a.context.Enable(PKESchemeFeature.LEVELEDSHE)
        a.context.Enable(PKESchemeFeature.ADVANCEDSHE)

        start = time.time()
        answer = solve(a.input, a.context, a.public_key)
        print("Execution time=", time.time() - start)

        if not SerializeToFile(args.output, answer, BINARY):
            raise Exception('output serialization failed')

    except Exception as err:
        print(f'execution error: {err}')
        sys.exit(1)
