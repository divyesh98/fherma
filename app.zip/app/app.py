import argparse
import sys
from openfhe import *
from numpy.polynomial import Chebyshev, Polynomial
import numpy as np
import concurrent.futures
import time

from concurrent.futures import ThreadPoolExecutor

class CKKSParser:
    def __init__(self):
        self.context = CryptoContext()
        self.public_key = None
        self.input = None


    def load(self, args):
        self.init_context(args.cc)
        self.init_public_key(args.key_public)
        
        
        with ThreadPoolExecutor() as executor:
            executor.submit(self.init_eval_mult_key, args.key_mult)
            executor.submit(self.init_rotation_key, args.key_rot)
            executor.submit(self.init_ciphertext, args.sample)


        #self.init_eval_mult_key(args.key_mult)
        #self.init_rotation_key(args.key_rot)
        #self.init_ciphertext(args.sample)


    def init_context(self, context_path):
        self.context, ok = DeserializeCryptoContext(context_path, BINARY)
        if not ok:
            raise Exception('load crypto context')


    def init_public_key(self, public_key_path):
        self.public_key, ok = DeserializePublicKey(public_key_path, BINARY)
        if not ok:
            raise Exception('load public key')


    def init_eval_mult_key(self, eval_key_path):
        if not self.context.DeserializeEvalMultKey(eval_key_path, BINARY):
            raise Exception('load mult key')


    def init_rotation_key(self, rotation_key_path):
        if not self.context.DeserializeEvalAutomorphismKey(rotation_key_path, BINARY):
            raise Exception('load rotation key')
        

    def init_ciphertext(self, ciphertext_path):
        self.input, ok = DeserializeCiphertext(ciphertext_path, BINARY)
        if not ok:
            raise Exception('load ciphertext')

def eval_mult(x, y, cc):
    return cc.EvalMult(x, y)

def solve(x, cc, pub_key):
    # put your solution here
    '''
    coefs = [9.999962350661752e-01,
    9.961808864042003e-01,
    4.892419015184620e-01,
    1.544794597916289e-01,
    3.402645877200605e-02,
    5.308589368342047e-03,
    5.741881580105659e-04,
    4.0776892561084950e-05,
    1.7022006971438345e-06,
	3.1527829096200395e-08
    ]
    
    x = inp
    
    x2 = cc.EvalMult(x, coefs[2]);
    x3 = cc.EvalMult(x, coefs[3]);
    x4 = cc.EvalMult(x, coefs[4]);
    x5 = cc.EvalMult(x, coefs[5]);
    x6 = cc.EvalMult(x, coefs[6]);
    x7 = cc.EvalMult(x, coefs[7]);
    x8 = cc.EvalMult(x, coefs[8]);
    x9 = cc.EvalMult(x, coefs[9]);

    x2 = cc.EvalMult(x2, x);
    x3 = cc.EvalMult(x3, x);
    x4 = cc.EvalMult(x4, x);
    x5 = cc.EvalMult(x5, x);
    x6 = cc.EvalMult(x6, x);
    x7 = cc.EvalMult(x7, x);
    x8 = cc.EvalMult(x8, x);
    x9 = cc.EvalMult(x9, x);
    
    res = cc.EvalMult(x, coefs[1]);
    res = cc.EvalAdd(res, coefs[0]);
    res = cc.EvalAdd(res, x2);
    res = cc.EvalAdd(res, x3);
    res = cc.EvalAdd(res, x4);
    res = cc.EvalAdd(res, x5);
    res = cc.EvalAdd(res, x6);
    res = cc.EvalAdd(res, x7);
    res = cc.EvalAdd(res, x8);
    res = cc.EvalAdd(res, x9);
    
    num = res

    for i in range(12):
        r = 1 << i
        temp = cc.EvalRotate(res, r)
        res = cc.EvalAdd(res, temp)
    
    res = cc.EvalMult(res, 1./1000)
    den = cc.EvalDivide(res, a=0.1, b=10, degree=3)
    den = cc.EvalMult(den, 1./1000)
    return cc.EvalMult(num, den)
    '''
    x_scale = cc.EvalMult(x, 1./50)
    #x_scale = cc.EvalMult(x_scale, 1./25)
    x_scale = cc.EvalAdd(x_scale, 0.4)

    x_train = np.linspace(0, 1)
    y_train = np.exp(x_train)
    cheb_fit_exp = Chebyshev.fit(x_train, y_train, 5, domain=[0, 1])

    poly_std = cheb_fit_exp.convert(kind=Polynomial)
    coefs = poly_std.coef

    x2 = cc.EvalMult(x_scale, x_scale)

    with concurrent.futures.ThreadPoolExecutor() as executor:
        future1 = executor.submit(eval_mult, x2, x_scale, cc)
        future2 = executor.submit(eval_mult, x2, x2, cc)
        x3 = future1.result()
        x4 = future2.result()
    
    x5 = cc.EvalMult(x2, x3)

    with concurrent.futures.ThreadPoolExecutor() as executor:
        future1 = executor.submit(eval_mult, x_scale, coefs[1], cc)
        future2 = executor.submit(eval_mult, x2, coefs[2], cc)
        future3 = executor.submit(eval_mult, x3, coefs[3],cc)
        future4 = executor.submit(eval_mult, x4, coefs[4], cc)
        future5 = executor.submit(eval_mult, x5, coefs[5], cc)

        x1_c = future1.result()
        x2_c = future2.result()
        x3_c = future3.result()
        x4_c = future4.result()
        x5_c = future5.result()

    res = cc.EvalAdd(x1_c, coefs[0])
    res = cc.EvalAdd(x2_c, res)
    res = cc.EvalAdd(x3_c, res)
    res = cc.EvalAdd(x4_c, res)
    res = cc.EvalAdd(x5_c, res)

    for i in range(12):
        r = 1 << i
        t = cc.EvalRotate(res, r)
        res = cc.EvalAdd(res, t)
    
    s = cc.EvalMult(res, 1./12000)

    x_train = np.linspace(-1, 1, 20000)
    y_train = 1./x_train
    cheb_fit_inv = Chebyshev.fit(x_train, y_train, 5, domain=[-1, 1])
    
    poly_inv = cheb_fit_inv.convert(kind=Polynomial)
    coefs = poly_inv.coef

    s2 = cc.EvalMult(s, s)

    with concurrent.futures.ThreadPoolExecutor() as executor:
        future1 = executor.submit(eval_mult, s2, s, cc)
        future2 = executor.submit(eval_mult, s2, s2, cc)
        s3 = future1.result()
        s4 = future2.result()

    s5 = cc.EvalMult(s2, s3)

    with concurrent.futures.ThreadPoolExecutor() as executor:
        future1 = executor.submit(eval_mult, s, coefs[1], cc)
        future2 = executor.submit(eval_mult, s2, coefs[2], cc)
        future3 = executor.submit(eval_mult, s3, coefs[3],cc)
        future4 = executor.submit(eval_mult, s4, coefs[4], cc)
        future5 = executor.submit(eval_mult, s5, coefs[5], cc)

        s1_c = future1.result()
        s2_c = future2.result()
        s3_c = future3.result()
        s4_c = future4.result()
        s5_c = future5.result()

    res = cc.EvalAdd(s1_c, coefs[0])
    res = cc.EvalAdd(s2_c, res)
    res = cc.EvalAdd(s3_c, res)
    res = cc.EvalAdd(s4_c, res)
    res = cc.EvalAdd(s5_c, res)

    return cc.EvalMult(x_scale, cc.EvalMult(res, 1./12000))

if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('--key_public')
        parser.add_argument('--key_mult')
        parser.add_argument('--key_rot')
        parser.add_argument('--cc')
        parser.add_argument('--sample')
        parser.add_argument('--output')
        args = parser.parse_args()

        a = CKKSParser()
        a.load(args)
        
        a.context.Enable(PKESchemeFeature.PKE)
        a.context.Enable(PKESchemeFeature.KEYSWITCH)
        a.context.Enable(PKESchemeFeature.LEVELEDSHE)
        a.context.Enable(PKESchemeFeature.ADVANCEDSHE)

        start = time.time()
        answer = solve(a.input, a.context, a.public_key)
        print("Execution time=", time.time() - start)

        if not SerializeToFile(args.output, answer, BINARY):
            raise Exception('output serialization failed')

    except Exception as err:
        print(f'execution error: {err}')
        sys.exit(1)
